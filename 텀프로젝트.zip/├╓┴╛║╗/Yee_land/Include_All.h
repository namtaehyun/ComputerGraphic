#pragma once
#ifndef Include_All
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <glut.h>
#include <Windows.h>
#include <time.h>
#include "Character.h"
#include "Camara.h"
#include "Monster.h"
#include "Bullet_List.h"
#include "collide.h"
#include "UI.h"
#include "Wall.h"
#include "Obstacle.h"
#include "Boss.h"
#include "Portion.h"
#pragma comment(lib, "winmm.lib") // �Ҹ��ֱ����

#endif // !Include_All
