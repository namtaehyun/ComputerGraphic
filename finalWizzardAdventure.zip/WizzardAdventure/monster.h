

#ifndef MONSTER__H__
#define MONSTER__H__
#include <gl/glut.h>
#include "Point3d.h"
#include "Cube.h"
#include "baseobj.h"
#include <math.h>
#define RAD 57.32

class monster :public baseobj
{
public:
	//�ִϸ��̼�
		  //��Ȳ���°� ������������ kind1 ���� 	    2 ~~ init 
	Cube arm[2];
	Cube head;
	Cube wand;
	Cube leg[4];
	Cube body;
	Cube tail;
	Cube HPbar;



	Cube golramarm[2];
	Cube golramleg[2];
	Cube golrambody[5];
	Cube golramhead;

	Cube colliderbox;

	int damage = 5;
	int fullhp = 0;
	int hp = 0;
	int mp = 0;
	int yspeed = 0;
	int xspeed = 5;
	int level = 0;
	int gravitymode = 1;
	int jumpcount = 0;
	int leggacdo = 0;
	int standtime = 0;
	int gacdostate = 0;
	int attackstate = 0;
	int attackgacdo = 0;
	Point3d gacdopos;
	int objgacdo = 0;


	int attacktime = 0;
	int move = 0;
	int xarrow = -1;		 // 0���� 1�� ��
	int zarrow = -1;
	int minpos[2];
	int maxpos[2];
	int movecount = 10;
	int attackdistance = 70;
	int followmode = 0;
	int MState = 0;
	int animationcount = 5;
	int monsterkind = 0;  
	int attackrange = 0;
	int checkgra = 1;
	monster(int kind, int ihp, int imp, int x, int y, int z)
	{
		monsterkind = kind-1;
		minpos[0] = -1;
		minpos[1] = -1;
			maxpos[0] = -1;
			maxpos[1] = -1;
		//ĳ����ũ��� 60����?
			HPbar.setcolor(1, 0, 0);
			if (monsterkind == 0)
			{
				//level = ilevel;
				
				hp = ihp;
				mp = imp;
				pos.x = x;
				pos.y = y;
				pos.z = z;

				fullhp = 200;
				hp = 200;
				//leg[0].init(-30, 0, 0, 20, 60, 20);
				//leg[1].init(30, 0, 0, 20, 60, 20);
				//	collidersize.x = 100;
				//	collidersize.y = 100;
				//	collidersize.z = -40;

				
			//�� �߾ӱ������� �ڽ����س����� ���ʳ����� �ؼ� �����ؼ� �ָ��ϴ�.
				collidersize.x = 45*3;
				collidersize.y = 45 * 3;
				collidersize.z = -45*3;
				//sin(gacdostate / RAD);
				 //cos(gacdostate / RAD); 42�� �� ���ϴ� -42

				/*
				collidersize.x = 40 * 3;
				collidersize.y = 40 * 3;
				collidersize.z = -600* 3;
				*/
				attackdistance =200;
				for (int i = 0; i < 4; ++i)
					leg[i].setcolor(0, 0, 0);
				body.setcolor(1, 0.4, 0.6);
				tail.setcolor(0.6, 1, 0.2);
				head.setcolor(0.4, 0.2, 1);

			}

			if (monsterkind == 1){
				//level = ilevel;

				hp = ihp;
				mp = imp;
				pos.x = x;
				pos.y = y;
				pos.z = z;

			//	fullhp = 200;
			//	hp = 200;
				//leg[0].init(-30, 0, 0, 20, 60, 20);
				//leg[1].init(30, 0, 0, 20, 60, 20);
				//   collidersize.x = 100;
				//   collidersize.y = 100;
				//   collidersize.z = -40;


				//�� �߾ӱ������� �ڽ����س����� ���ʳ����� �ؼ� �����ؼ� �ָ��ϴ�.
				collidersize.x = 600;
				collidersize.y = 700;
				collidersize.z = -600;
				//sin(gacdostate / RAD);
				//cos(gacdostate / RAD); 42�� �� ���ϴ� -42

				/*
				collidersize.x = 40 * 3;
				collidersize.y = 40 * 3;
				collidersize.z = -600* 3;
				*/
				attackdistance = 200;
				for (int i = 0; i < 2; ++i){
					golramleg[i].setcolor(0, 0, 0);
					golramarm[i].setcolor(0.2, 0.6, 0.4);
				}
				for (int i = 0; i < 5; ++i)
					golrambody[i].setcolor(1, 0.4, 0.6);
				head.setcolor(0.4, 0.2, 1);
			}
	}

	void update()
	{
		HPbar.init(pos.x - 80, pos.y +collidersize.y+50, pos.z + 15, (hp), 30, 30);
		//���Ⱒ��
	//	collidersize.x = 40 * 3 * 1 * cos(gacdostate / RAD) + (-45 * 3 * sin(gacdostate / RAD));
	//	collidersize.y = 40 * 3;
	//	collidersize.z = -45 * 3 * cos(gacdostate / RAD) + (40 * 3 * sin(gacdostate / RAD));
		//collidersize.x = 40 * 3;
		/*if (gacdostate> 0 && gacdostate < 180)
		{
			collidersize.x = -40 * 3;
		}
		else
		{
			collidersize.x = 40 * 3;
		}
		*/
	//	collidersize.y = 40 * 3;
	//	collidersize.z = -45 * 3;


		if (animationcount > 0)
		{
			animationcount--;
		}
		if (movecount > 0 && followmode==0)
		{
			move = 1;
			movecount--;
		}
		if (movecount <= 0)
		{
			gacdostate= (rand() % 4) * 90; // 0�� 90�� 180�� 270��  
			
			movecount = 200;

		}

		
		if (attacktime <= 100 && attacktime>50)	 //ó��
		{
			if (attacktime % 1 == 0)
				attackgacdo += 5; //1:1
			attacktime-=5;

			pos.x -= 10* sin(gacdostate / RAD);
			pos.z -= 10* cos(gacdostate / RAD);
			//�����ΰ���
		}
		else  if (attacktime <= 50 && attacktime>0)
		{
			if (attacktime % 1 == 0)
				attackgacdo -= 1;
			attacktime-=1;
			pos.x += 2 * sin(gacdostate / RAD);	  //�����ΰ���
			pos.z += 2* cos(gacdostate / RAD);		 //�����ΰ���
		}
		if (attacktime <= 0 && attackstate == 1)
		{
			//attacktime = 0;
			attackstate = 0;
		}

		   
		if (standtime > 100)
		{
			leggacdo = 0;
			standtime = 0;
		}
		else
		{
			standtime++;
		}

		if (gravitymode == 0)
		{
			//pos.y -= 9.8;
		}
		if (gravitymode == 1 && jumpcount == 0)
		{
			pos.y -= 5;
		}

		if (move == 1 && MState<=1)	  //������ 
		{			
			if (animationcount <= 0)
			{
				if (leggacdo == 0)	 //	   �߾�
				{
					leggacdo = 1;
				}
				else if (leggacdo == 1)
				{
					leggacdo = -1;
				}
				else if (leggacdo == -1)
				{
					leggacdo = 1;
				}
				animationcount = 5;
			}

		
			
				pos.x -= 2 * sin(gacdostate / RAD);
				pos.z -= 2 * cos(gacdostate / RAD);
			
				if (maxpos[0] != -1)
				{
					if (pos.x < maxpos[0] + 100) //�����������
					{								 //pos.x�� �������
						pos.x = maxpos[0] + 100;
					}
					if (pos.z < minpos[1] +100)
					{
						//minpos ��û -1500������ -1499���� ����̵Ǿ���
						pos.z = minpos[1] + 100;

					}
					if (pos.z > maxpos[1] - 100) //�� �������� +500��ŭ���� ū��츸.
					{						   
						pos.z = maxpos[1] - 100;
					}
					//����ū���
					if (pos.x > minpos[0] - 100)
					{
						pos.x = minpos[0] - 100;
					}
				}
			//����4���� ������ �����ϰ�

		
		}

		if (MState == 2)
		{

			if (attackstate == 0 )
			{
				attackmode();
			}

		}
		/*
		leg[0].init(pos.x + 15, pos.y + 0, pos.z - 15, 10, 50, 10);
		leg[1].init(pos.x + 35, pos.y + 0, pos.z - 15, 10, 50, 10);
		body.init(pos.x + 10, pos.y + 50, pos.z - 10, 40, 50, 20);
		arm[0].init(pos.x + 0, pos.y + 60, pos.z - 15, 10, 35, 10);
		arm[1].init(pos.x + 50, pos.y + 60, pos.z - 15, 10, 35, 10);
		head.init(pos.x + 20, pos.y + 100, pos.z - 10, 20, 20, 20);
		wand.init(pos.x + 52, pos.y + 62, pos.z - 25, 6, 6, 50);
		  */

		colliderbox.init(pos.x, pos.y, pos.z, collidersize.x, collidersize.y, -collidersize.z);   //ť��������ҋ� ������´�.

		if (monsterkind == 0)
		{
			leg[0].init(pos.x + (1 * 3), pos.y, pos.z - (8 * 3), 5 * 3, 12 * 3, 5 * 3);
			leg[1].init(pos.x + (8 * 3), pos.y, pos.z - (8 * 3), 5 * 3, 12 * 3, 5 * 3);
			leg[2].init(pos.x + (1 * 3), pos.y, pos.z - (29 * 3), 5 * 3, 12 * 3, 5 * 3);
			leg[3].init(pos.x + (8 * 3), pos.y, pos.z - (29 * 3), 5 * 3, 12 * 3, 5 * 3);
			body.init(pos.x, pos.y + (12 * 3), pos.z - (7 * 3), 14 * 3, 14 * 3, 30 * 3);
			tail.init(pos.x + (4 * 3), pos.y + (23 * 3), pos.z, 6 * 3, 6 * 3, 6 * 3);
			head.init(pos.x, pos.y + (26 * 3), pos.z - (28 * 3), 14 * 3, 14 * 3, 14 * 3);

	

			/*
			leg[0].update();
			leg[1].update();
			body.update();
			arm[0].update();
			arm[1].update();
			head.update();
			wand.update();
			*/
			colliderbox.update();
			leg[0].update();
			leg[1].update();
			leg[2].update();
			leg[3].update();
			body.update();
			tail.update();
			head.update();

		}
		if (monsterkind == 1){
			colliderbox.init(pos.x, pos.y, pos.z, collidersize.x, collidersize.y, -collidersize.z);   //ť��������ҋ� ������´�.


			golramleg[0].init(pos.x + 150, pos.y, pos.z, 100, 200, -100);
			golramleg[1].init(pos.x + 350, pos.y, pos.z, 100, 200, -100);
			golramarm[0].init(pos.x, pos.y + 300, pos.z, 100, 250, -100);
			golramarm[1].init(pos.x + 500, pos.y + 300, pos.z, 100, 250, -100);
			golrambody[0].init(pos.x + 100, pos.y + 500, pos.z, 100, 100, -100);
			golrambody[1].init(pos.x + 200, pos.y + 400, pos.z, 200, 200, -100);
			golrambody[2].init(pos.x + 400, pos.y + 500, pos.z, 100, 100, -100);
			golrambody[3].init(pos.x + 250, pos.y + 300, pos.z, 100, 100, -100);
			golrambody[4].init(pos.x + 200, pos.y + 200, pos.z, 200, 100, -100);
			golramhead.init(pos.x + 250, pos.y + 600, pos.z, 120, 120, -120);

			colliderbox.update();
			golramleg[0].update();
			golramleg[1].update();
			golramarm[0].update();
			golramleg[1].update();
			golrambody[0].update();
			golrambody[1].update();
			golrambody[2].update();
			golrambody[3].update();
			golrambody[4].update();
			golramhead.update();

		}
	}

	void attackmode()
	{
		attackstate = 1;
		attacktime = 100;
	}
	int hitcollider(baseobj *obj)
	{
		//���� y�����̿� �ְ�  x z �൵ ���̿��ִ°��.		  //����Ʈ x���� ����+���丷�����ΰ��.
		int xsize = collidersize.x / 2;

		Point3d largesize;
		//largesize
		largesize.x = (collidersize.x > obj->collidersize.x) ? (collidersize.x) : (obj->collidersize.x);
		largesize.y = (collidersize.y > obj->collidersize.y) ? (collidersize.y) : (obj->collidersize.y);
		largesize.z = (collidersize.z > obj->collidersize.z) ? (obj->collidersize.z) : (collidersize.z);
		//x�񱳴� ������ x��- ����Ʈx��-ũ��� �� ����.
		//	if (((pos.x + xsize - obj->pos.x - (collidersize.x / 2)))>-70 && ((pos.x + xsize - obj->pos.x - (collidersize.x / 2)))<70)
		//������ collider
		if (((pos.x + (collidersize.x / 2) - obj->pos.x - (obj->collidersize.x / 2))  >	-largesize.x / 2) && ((pos.x + (collidersize.x / 2) - obj->pos.x - (obj->collidersize.x / 2))  <	largesize.x/ 2))
		{
			//printf("x�� ����  \n");
			//���� �߾Ӱ�-�ĺ����߾Ӱ����� ĳ�����븸�Ѱ��
			//if ((obj->pos.y<(pos.y + (collidersize.y / 2))) && ((obj->pos.y + obj->collidersize.y)>(pos.y + (collidersize.y))))
			//����-����Ʈ�� �� ������ /2 �ȿ� ���°��
		//	if (pos.y - obj->pos.y > -collidersize.y / 2 && pos.y - obj->pos.y < collidersize.y / 2)
			if( ((pos.y + (collidersize.y/ 2) - obj->pos.y - (obj->collidersize.y / 2))  >	-largesize.y / 2) && ((pos.y + (collidersize.y / 2) - obj->pos.y - (obj->collidersize.y / 2))  <	largesize.y / 2)	 )
			{
				//printf("y�´��� \n");

			//	if (obj->pos.z - pos.z > -(obj->collidersize.z/2) && obj->pos.z - pos.z < 100)	 //���Ϳ� ������z�ప�����̰� 100����
			//if (obj->pos.z - pos.z >(obj->collidersize.z) && obj->pos.z - pos.z <  -(obj->collidersize.z))	 //���Ϳ� ������z�ప�����̰� 100����
				//���� ���廫���� ĳ���ͻ�����ݰ�����
				//return 1;
				if ((pos.z + collidersize.z / 2 - (obj->pos.z + obj->collidersize.z / 2)) <-(largesize.z/2) && (pos.z+collidersize.z/2- (obj->pos.z + obj->collidersize.z / 2) ) > (largesize.z/2) )
			{					
					//��
					//colldiersize z �� -
				//���� ����Ʈ�����ǖA���� ���ݻ����̳��ΰ��.
			//	printf("z�´��� \n");
				return 1;
			}
			}

		}
		//���Ϳ� 
		return 0;
	}


	/*
	int hitcollider(baseobj *obj)
	{
		//���� y�����̿� �ְ�  x z �൵ ���̿��ִ°��.		  //����Ʈ x���� ����+���丷�����ΰ��.
		int xsize = collidersize.x / 2;
		
		//if (gacdostate > 0 && gacdostate < 180)
		//{
	//		xsize -= xsize;
	//	}
		   

		 //x�񱳴� ������ x��- ����Ʈx��-ũ��� �� ����.
	//	if (((pos.x + xsize - obj->pos.x - (collidersize.x / 2)))>-70 && ((pos.x + xsize - obj->pos.x - (collidersize.x / 2)))<70)
		if (obj->pos.x- pos.x >-(obj->collidersize.x / 2) && obj->pos.x - pos.x <  (obj->collidersize.x / 2))
		{ //���� �߾Ӱ�-�ĺ����߾Ӱ����� ĳ�����븸�Ѱ��
			if ((obj->pos.y<(pos.y + (collidersize.y / 2))) && ((obj->pos.y + obj->collidersize.y)>(pos.y + (collidersize.y / 2))))
			{
				
				
			//	if (obj->pos.z - pos.z > -(obj->collidersize.z/2) && obj->pos.z - pos.z < 100)	 //���Ϳ� ������z�ప�����̰� 100����
				if (obj->pos.z - pos.z > (obj->collidersize.z / 2) && obj->pos.z - pos.z <  -(obj->collidersize.z / 2))	 //���Ϳ� ������z�ప�����̰� 100����
				{
					return 1;
				}
			}
		
		}
		//���Ϳ� 
		return 0;
	}
	*/
	int collider(baseobj *obj)
	{
		//if������Ʈ�̸��� floor�ΰ�� y���浹üũ�� 
		
		if ((obj->pos.x<(pos.x + (collidersize.x / 2))) && (obj->pos.x + obj->collidersize.x>(pos.x + (collidersize.x / 2))))
		{
	
			if ((obj->pos.z>(pos.z + (collidersize.z / 2))) && (obj->pos.z + obj->collidersize.z<(pos.z + (collidersize.z / 2))))

			{

				if ((pos.y - (obj->pos.y + obj->collidersize.y)) >= 0 && (pos.y - (obj->pos.y + obj->collidersize.y)) <= 10)
				{
					//pos.y
					//�ٴڰ� ĳ���� ĳ��-�ٴ��� 0~10�����ΰ��
					if (minpos[0] == -1 && maxpos[0]==-1)

					{
						minpos[0] = obj->pos.x + obj->collidersize.x;
						maxpos[0] = obj->pos.x ;

						minpos[1] = obj->pos.z + obj->collidersize.z;
						maxpos[1] = obj->pos.z;

					}

					pos.y = obj->pos.y + obj->collidersize.y;
					return 1;
				}
			}
		}

		return 0;
	}

	void draw()
	{
	
		
	//colliderbox.draw();
	//glLoadIdentity();
	

	//floor

		//�������������.
		//body.init(pos.x, pos.y + (12 * 3), pos.z - (7 * 3), 14 * 3, 14 * 3, 30 * 3);
		if (monsterkind == 0)
		{
			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);
			HPbar.draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);

			glRotatef(leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);
			//leg[0].setxgacdo(leggacdo * 40);
			leg[0].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);

			glRotatef(-leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);
			leg[1].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);
			glRotatef(attackgacdo, 1, 0, 0);
			glRotatef(leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);
			//leg[0].setxgacdo(leggacdo * 40);
			leg[2].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);
			glRotatef(attackgacdo, 1, 0, 0);
			glRotatef(-leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);

			leg[3].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);
			body.draw();
			glLoadIdentity();


			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);
			tail.draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 20, body.pos.z - 40);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 20, -body.pos.z + 40);

			head.draw();
			glLoadIdentity();

			/*
			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);

			glRotatef(leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
			//leg[0].setxgacdo(leggacdo * 40);
			leg[0].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glRotatef(-leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);

			leg[1].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glRotatef(attackgacdo, 1, 0, 0);
			glRotatef(leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
			//leg[0].setxgacdo(leggacdo * 40);
			leg[2].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glRotatef(attackgacdo, 1, 0, 0);
			glRotatef(-leggacdo * 10, 1, 0, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);

			leg[3].draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
			body.draw();
			glLoadIdentity();


			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
			tail.draw();
			glLoadIdentity();

			glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);

			head.draw();
			glLoadIdentity();
			*/
		}

		if (monsterkind == 1)
		{
			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			HPbar.draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y -350, -pos.z + 100);
			golramleg[0].draw();

			glLoadIdentity();
			glTranslatef(pos.x + 300, pos.y + 350,pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golramleg[1].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golramarm[0].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golramarm[1].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golrambody[0].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golrambody[1].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golrambody[2].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golrambody[3].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golrambody[4].draw();
			glLoadIdentity();
			glTranslatef(pos.x + 300, pos.y + 350, pos.z - 100);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-pos.x - 300, -pos.y - 350, -pos.z + 100);
			golramhead.draw();
			glLoadIdentity();


		}

	}


};












#endif

