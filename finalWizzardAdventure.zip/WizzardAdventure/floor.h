#ifndef FLOOR__H__
#define FLOOR__H__
#include<gl/glut.h>
#include "Point3d.h"
#include<stdlib.h>
#include<time.h>
#include "baseobj.h"
#include "Cube.h"

class Floor:public baseobj
{
public:
	//Cube floorcube[100][10][100];
	Cube ***floorcube;
	int xcount;
	int ycount;
	int zcount;
	int rectsize = 50;
	int scenenum;
	int kind = 0;
	int movecoll = 0;
	//���� 2���� �����

	Floor(int x, int y, int z, int ixcount, int iycount, int izcount,int cubesize=50)
	{
		srand(time(NULL));

		//ĳ����ũ��� 60����?
		xcount = ixcount;
		ycount = iycount;
		zcount = izcount;
				   //x y z ����

		floorcube = new Cube**[xcount];
		for (int i = 0; i < xcount; i++)
			floorcube[i] = new Cube*[ycount];


		for (int n = 0; n < xcount; n++)
		{
			for (int i = 0; i < ycount; i++)
				floorcube[n][i] = new Cube[zcount];
		}
		


		pos.x = x;
		pos.y = y;
		pos.z = z;
		rectsize = cubesize;
		collidersize.x = rectsize*xcount;
		collidersize.y = rectsize * ycount;
		collidersize.z = -(rectsize*zcount);

		for (int x = 0; x < xcount; x++)
		{

			for (int y = 0; y < ycount; y++)
			{
				for (int z = 0; z < zcount; z++)
				{
					floorcube[x][y][z].init(pos.x + x * rectsize, pos.y + y * rectsize, pos.z - (z * rectsize), rectsize, rectsize, rectsize);
					

					int r[3] = { rand() % 2, rand() % 2, rand() % 2 };
					floorcube[x][y][z].setcolor(255*r[0],255*r[1],255*r[2]);

					/*if (x == z)
					{
						floorcube[x][y][z].setcolor((z + 1) * 0.1 * (x + 1)*0.1, (z + 1) * 0.1 * 0.1*(x + 1), (z + 1) * 0.1 * (x + 1)*0.1);
					}
					*/
					/*
					if (z < zcount / 2)
					{
						floorcube[x][y][z].setcolor((z + 1) * 0.3 * (x + 1)*0.3, (z + 1) * 0.3 * 0.3*(x + 1), (z + 1) * 0.3 * (x + 1)*0.3);
					}
					else
					{
						floorcube[x][y][z].setcolor( -(z + 1) * 0.3 * (x + 1)*0.3, -(z + 1) * 0.3 * 0.3*(x + 1), -(z + 1) * 0.3 * (x + 1)*0.3);
					}
					*/
					//������������  z�������ΰ�� ���������� -
					//z�������ø��� �ش�z���� ������ ���������ιٲ�
					//floorcube[0][0][0].setcolor(255, 255, 255);
					//floorcube[x][y][z].setcolor(255 - 255 / (x + 1), 255 - 255 / (y+ 1), 255-255 / (z + 1));
					//floorcube[x][y][z].setcolor(255/(xcount+1)*x, 255/(xcount+1)*x, 255/(xcount+1)*x); //0~255����������
				}

			}

		}



	}

	void update()
	{	
		
		if (kind == 2)
		{
			static int arrow = 1;
				if (pos.y > 3000)
					arrow = -1;

			if (pos.y < -500)
				arrow = 1;


			pos.y += arrow * 6;

			for (int x = 0; x < xcount; x++)
			{

				for (int y = 0; y < ycount; y++)
				{
					for (int z = 0; z < zcount; z++)
					{
						floorcube[x][y][z].init(pos.x + x * rectsize, pos.y + y * rectsize, pos.z - (z * rectsize), rectsize, rectsize, rectsize);

					}
				}
			}
		}
		  
		//floorcube[x][y][z] x��0�϶� �̵������� 3����¶�
		for (int x = 0; x < xcount; x++)
		{

			for (int y = 0; y < ycount; y++)
			{
				for (int z = 0; z < zcount; z++)
				{
				//	floorcube[x][y][z].update();
				}

			}
			
		}
	//	leg[0].init(pos.x + 30, pos.y + 0, pos.z + 0, 20, 60, 20);
	//	leg[1].init(pos.x + 90, pos.y + 0, pos.z + 0, 20, 60, 20);
	//	body.init(pos.x + 30, pos.y + 60, pos.z, 80, 40, 40);
		//leg[0].update();
		//leg[1].update();
		//body.update();


	}
	int collider(baseobj *obj)
	{
		//if������Ʈ�̸��� floor�ΰ�� y���浹üũ�� 
		if (obj->pos.y + obj->collidersize.y == pos.y)
		{
			return 1;
		}

		return 0;
	}

	void draw()
	{
		/*
		glColor3f(0, 0, 0);
		glBegin(GL_LINE_LOOP);
		for (int ty = 0; ty <= ycount; ty++)
		{
			glVertex3f(pos.x, pos.y + ty * 50, pos.z);
			glVertex3f(pos.x + xcount * 50, pos.y + ty * 50, pos.z);
			glVertex3f(pos.x + xcount * 50, pos.y + ty * 50, pos.z - (zcount * 50));
			glVertex3f(pos.x, pos.y + ty * 50, pos.z - (zcount * 50));
		}
		glEnd();
		*/
		for (int x = 0; x < xcount; x++)
		{

			for (int y = 0; y < ycount; y++)
			{
				for (int z = 0; z < zcount; z++)
				{
					floorcube[x][y][z].draw();
				}

			}

		}
	}



};





#endif
