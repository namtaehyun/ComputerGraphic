#ifndef BASEOBJ__H__  //A
#define BASEOBJ__H__	 //A

#include<gl/glut.h>
#include "Point3d.h"

class baseobj{
public:
	Point3d pos;
	Point3d collidersize;
	baseobj()
	{

	}
	virtual void init(float x, float y, float z, double xcubesize = 50, double ycubesize = 50, double zcubesize = 50)
	{

	}
	virtual void update()
	{

	}
	virtual void draw()
	{

	}
	virtual int collider(baseobj *)
	{
		return -1;
	}
	virtual void setcolor(float, float, float)
	{

	}


};
#endif