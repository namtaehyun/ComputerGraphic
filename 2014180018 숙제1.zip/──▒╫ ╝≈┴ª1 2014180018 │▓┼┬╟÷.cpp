﻿/*
사각형(It)을 잘라서 (Slice) 바구니에 받기 (Take)
• 화면의 상단에서 사각형이 좌우로 움직인다.
• 마우스를 이용하여 사각형을 자른다.
• 방법 1: 사각형의 한쪽 선에 점을 찍고 반대편에 점을 찍어서 두 점을 연결하여 자르고 사각형 2개를 만든다.
• 방법 2: 마우스를 이용하여 선을 그려 자유롭게 사각형을 2개로 자른다. (방법 1보다 높은 점수)
• 잘려진 사각형 중 크기가 작은  사각형이 아래로 떨어진다.
• 아래에는 바구니가 좌우로 움직이고 있고, 떨어지는 사각형이 바구니 안에 들어간다.
• 사각형이 바구니 밖으로 떨어지면 화면 밖으로 나간다.
• 키보드 명령
• p/P: 새로운 사각형이 새로운 크기로 다시 나타난다.
• q/Q: 프로그램 종료
게임의 규칙
• 바구니 안에는 물이 있고 (다른 색의 사각형으로 표시),
사각형이 물에 들어가면 클리핑되어 사각형의 가장자리 색이 다르게 표현된다.
• 사각형은 바구니 안에 들어갈 수도 있고, 안 들어갈 수도 있고, 바구니 의 모서리에 멈춰져 있을 수도 있다.
• 바구니 안의 물의 높이가 올라갔다 내려갔다 한다.  (파도를 표현한 것 임)

*/


#include <math.h>
#include "Conversion.h"
#include <gl\GL.h>
#include <glut.h>
#include <stdio.h>    // 또는 <GL/freeglut.h>
#include <stdlib.h>
void CohenSutherlandLineClipAndDraw(double x0, double y0, double x1, double y1, double xmax, double xmin, double ymax, double ymin);
int ComputeOutCode(double x, double y, double xmax, double xmin, double ymax, double ymin);

const int INSIDE = 0; // 0000
const int LEFT = 1;   // 0001
const int RIGHT = 2;  // 0010
const int BOTTOM = 4; // 0100
const int TOP = 8;    // 1000

void Motion(int x, int y);
void Mouse(int button, int state, int x, int y);
GLvoid KeyBoardInput(unsigned char key, int x, int y);
GLvoid drawScene(GLvoid);
GLvoid reshape(int w, int h);
GLvoid Timer(int value);

struct Bucket
{
	double x, y; //Bucket의 절대좌표값
	int time; //Bucket의 시간
};


struct Rect
{
	bool garo;
	int time; //Rect의 시간
	double x, y; // Rect의 절대좌표값(중심점)
	double size; // Rect의 크기
	bool cut; //잘렸는지 안 잘렸는지
	Rect()
	{
		cut = false;
		size = rand() % 10 * 0.01 + 0.1;
		time = 0;
	}
};

struct CutShape
{
	double LefttopX, LefttopY,
		RighttopX, RighttopY,
		LeftbottomX, leftbottomY,
		RightbottomX, RightbottomY; // 사각형의 좌표값들
	double size; //잘린사각형의 둘레 구해서 넣을꺼임.
	double  x, y;// 잘린 사각형의 절대 좌표값
	bool collide;// 사각형이 버켓에 충돌했을 경우
	bool bcollide;
};



struct window // 윈도우 관련 변수들
{
	double Width, Height; // 너비와 높이
	double lineX1, lineY1; // 자르는 라인의 첫 좌표
	double lineX2, lineY2; //자르는 라인의 끝 좌표
	double cly1, cly2; //클리핑된 좌표
	double clx1, clx2; //클리핑된 좌표
	bool click; //클릭했을때와 안 클릭했을때
	int cutTime; // 사각형이 잘렸을때 떨어지지 않은 사각형이 계속 가기위해 만든변수
	window()
	{
		cutTime = 0;
		Width = 700;
		Height = 700;
	}
};

Rect rt;
Bucket bt;
window Windows;
CutShape cs[2];
double m; //기울기
double abs1; //절대값
double ph; // 가로위에있는녀석을 이만큼 움직여준다.
int dir; //방향
int angle;

void main(int argc, char** argv) {
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(700, 700);
	glutCreateWindow("Example1");
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutTimerFunc(100, Timer, 1);
	glutMouseFunc(Mouse);
	glutMotionFunc(Motion);
	glutKeyboardFunc(KeyBoardInput);
	glutDisplayFunc(drawScene);
	glutReshapeFunc(reshape);
	glutMainLoop();
}

GLvoid drawScene()     // 출력 함수 
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);    // 바탕색을 'blue' 로 지정       
	glClear(GL_COLOR_BUFFER_BIT);   // 설정된 색으로 젂체를 칠하기      

	if (Windows.click == true) {
		glBegin(GL_LINES);
		glVertex2f(Windows.lineX1, Windows.lineY1);
		glVertex2f(Windows.lineX2, Windows.lineY2);
		glEnd();
	}

	if (rt.cut == false) {
		glPushMatrix();// 잘라지지 않은 사각형을 그린다.
		if (rt.time<20)
		{
			dir = 1;
			glTranslatef(-1 + 0.1*rt.time, 0.5, 0);
			rt.x = -1 + 0.1*rt.time;
			rt.y = 0.5;
		}
		else if (rt.time >= 20 && rt.time < 40)
		{
			dir = 2;
			glTranslatef(1 - 0.1*(rt.time - 20), 0.5, 0);
			rt.x = 1 - 0.1*(rt.time - 20);
			rt.y = 0.5;
		}
		else
		{
			glTranslatef(-1, 0.5, 0);
			rt.time = 0;
			rt.x = -1;
			rt.y = 0.5;
		}
		glColor3f(1, 1, 1);
		glRectf(-rt.size, -rt.size, rt.size, rt.size);
		glPopMatrix();
	}
	else
	{
		glPushMatrix();
		if (cs[0].collide == false) {
			if (cs[0].size < cs[1].size)
			{
				glTranslatef(rt.x, 0.5 - Windows.cutTime*0.1 - rt.size, 0);
			}
			else
			{
				if (dir == 1) {
					glTranslatef(rt.x + Windows.cutTime*0.1, 0.5 - rt.size, 0);
				}
				else
				{
					glTranslatef(rt.x + Windows.cutTime*(-0.1), 0.5 - rt.size, 0);
				}
			}
		}
		else
		{
			if (bt.time<40)
			{
				glTranslatef(-1 + 0.05*bt.time, -0.5, 0);
			}
			else if (bt.time >= 40 && bt.time < 80)
			{
				glTranslatef(1 - 0.05*(bt.time - 40), -0.5, 0);
			}
			else
			{
				glTranslatef(-1, -0.5, 0);
			}
		}
		if (cs[0].bcollide == true&&cs[0].collide==false)
		{
			glRotatef(angle, 0, 0, 1);
		}
		glBegin(GL_QUADS);
		glVertex2f(cs[0].LeftbottomX, cs[0].leftbottomY);
		glVertex2f(cs[0].RightbottomX, cs[0].RightbottomY);
		glVertex2f(cs[0].RighttopX, cs[0].RighttopY);
		glVertex2f(cs[0].LefttopX, cs[0].LefttopY);
		glEnd();
		glPopMatrix();

		glPushMatrix();
		if (cs[1].collide == false) {
			if (cs[0].size < cs[1].size)
			{
				if (dir == 1) {
					glTranslatef(rt.x + Windows.cutTime*0.1, 0.5 - rt.size, 0);
				}
				else
				{
					glTranslatef(rt.x + Windows.cutTime*(-0.1), 0.5 - rt.size, 0);
				}
			}
			else
			{
				glTranslatef(rt.x, 0.5 - Windows.cutTime*0.1 - rt.size, 0);
			}
		}
		else
		{
			if (rt.garo == false) {
				if (bt.time < 40)
				{
					glTranslatef(-1 + 0.05*bt.time, -0.5, 0);
				}
				else if (bt.time >= 40 && bt.time < 80)
				{
					glTranslatef(1 - 0.05*(bt.time - 40), -0.5, 0);
				}
				else
				{
					glTranslatef(-1, -0.5, 0);
				}
			}
			else
			{
				if (bt.time < 40)
				{
					glTranslatef(-1 + 0.05*bt.time, -0.5 - ph, 0);
				}
				else if (bt.time >= 40 && bt.time < 80)
				{
					glTranslatef(1 - 0.05*(bt.time - 40), -0.5 - ph, 0);
				}
				else
				{
					glTranslatef(-1, -0.5 - ph, 0);
				}
			}
		}
		if (cs[1].bcollide == true && cs[1].collide == false)
		{
			glRotatef(angle, 0, 0, 1);
		}
		glBegin(GL_QUADS);
		glVertex2f(cs[1].LeftbottomX, cs[1].leftbottomY);
		glVertex2f(cs[1].RightbottomX, cs[1].RightbottomY);
		glVertex2f(cs[1].RighttopX, cs[1].RighttopY);
		glVertex2f(cs[1].LefttopX, cs[1].LefttopY);
		glEnd();
		glPopMatrix();
	}

	glPushMatrix();
	glColor3f(1, 1, 1);
	if (bt.time<40)
	{
		glTranslatef(-1 + 0.05*bt.time, -0.5, 0);
		bt.x = -1 + 0.05*bt.time;
		bt.y = -0.5;
	}
	else if (bt.time >= 40 && bt.time < 80)
	{
		glTranslatef(1 - 0.05*(bt.time - 40), -0.5, 0);
		bt.x = 1 - 0.05*(bt.time - 40);
		bt.y = -0.5;
	}
	else
	{
		glTranslatef(-1, -0.5, 0);
		bt.time = 0;
		bt.x = -1;
		bt.y = -0.5;
	}
	glBegin(GL_LINES);
	glVertex2f(-0.3, 0.3);
	glVertex2f(-0.3, 0);
	glVertex2f(-0.3, 0);
	glVertex2f(0.3, 0);
	glVertex2f(0.3, 0);
	glVertex2f(0.3, 0.3);
	glEnd(); // 양동이 틀


	glColor3f(0, 0, 1);
	glBegin(GL_QUADS);
	if (bt.time % 2 == 0) {
		glVertex2f(-0.3, 0.1);
		glVertex2f(-0.3, 0);
		glVertex2f(0.3, 0);
		glVertex2f(0.3, 0.1);
	}
	else if (bt.time % 2 == 1)
	{
		glVertex2f(-0.3, 0.05);
		glVertex2f(-0.3, 0);
		glVertex2f(0.3, 0);
		glVertex2f(0.3, 0.05);
	}
	glEnd();


	if (cs[0].collide == true && cs[1].collide == false && rt.garo == true) {
		if (bt.time % 2 == 0) {
			//		glVertex2f(cs[0].LeftbottomX, cs[0].leftbottomY);
			//		glVertex2f(cs[0].RightbottomX, cs[0].RightbottomY);
			//		glVertex2f(cs[0].RighttopX, cs[0].RighttopY);
			//		glVertex2f(cs[0].LefttopX, cs[0].LefttopY);
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].LeftbottomX, cs[0].leftbottomY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[0].RighttopX, cs[0].RighttopY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].RighttopX, cs[0].RighttopY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LeftbottomX, cs[0].leftbottomY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.1, 0);
		}
		else
		{
			//		glVertex2f(cs[0].LeftbottomX, cs[0].leftbottomY);
			//		glVertex2f(cs[0].RightbottomX, cs[0].RightbottomY);
			//		glVertex2f(cs[0].RighttopX, cs[0].RighttopY);
			//		glVertex2f(cs[0].LefttopX, cs[0].LefttopY);
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].LeftbottomX, cs[0].leftbottomY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[0].RighttopX, cs[0].RighttopY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].RighttopX, cs[0].RighttopY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LeftbottomX, cs[0].leftbottomY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.05, 0);
		}
	}
	else if (cs[1].collide == true && cs[0].collide == false && rt.garo == true) {
		if (bt.time % 2 == 0) {
			CohenSutherlandLineClipAndDraw(cs[1].LeftbottomX, cs[1].leftbottomY - ph, cs[1].RightbottomX, cs[1].RightbottomY - ph, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[1].RightbottomX, cs[1].RightbottomY - ph, cs[1].RighttopX, cs[1].RighttopY - ph, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LeftbottomX, cs[1].leftbottomY - ph, cs[1].LefttopX, cs[1].LefttopY - ph, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LefttopX, cs[1].LefttopY - ph, cs[1].RighttopX, cs[1].RighttopY - ph, 0.3, -0.3, 0.1, 0);
		}
		else
		{
			CohenSutherlandLineClipAndDraw(cs[1].LeftbottomX, cs[1].leftbottomY - ph, cs[1].RightbottomX, cs[1].RightbottomY - ph, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[1].RightbottomX, cs[1].RightbottomY - ph, cs[1].RighttopX, cs[1].RighttopY - ph, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LeftbottomX, cs[1].leftbottomY - ph, cs[1].LefttopX, cs[1].LefttopY - ph, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LefttopX, cs[1].LefttopY - ph, cs[1].RighttopX, cs[1].RighttopY - ph, 0.3, -0.3, 0.05, 0);
		}
	}
	else if (cs[0].collide == true && cs[1].collide == false && rt.garo == false)
	{
		if (bt.time % 2 == 0) {
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].LeftbottomX, cs[0].leftbottomY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[0].RighttopX, cs[0].RighttopY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].RighttopX, cs[0].RighttopY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LeftbottomX, cs[0].leftbottomY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.1, 0);
		}
		else
		{
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].LeftbottomX, cs[0].leftbottomY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[0].RighttopX, cs[0].RighttopY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LefttopX, cs[0].LefttopY, cs[0].RighttopX, cs[0].RighttopY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[0].LeftbottomX, cs[0].leftbottomY, cs[0].RightbottomX, cs[0].RightbottomY, 0.3, -0.3, 0.05, 0);
		}
	}
	else if (cs[1].collide == true && cs[0].collide == false && rt.garo == false)
	{
		if (bt.time % 2 == 0) {
			CohenSutherlandLineClipAndDraw(cs[1].LefttopX, cs[1].LefttopY, cs[1].LeftbottomX, cs[1].leftbottomY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[1].RighttopX, cs[1].RighttopY, cs[1].RightbottomX, cs[1].RightbottomY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LefttopX, cs[1].LefttopY, cs[1].RighttopX, cs[1].RighttopY, 0.3, -0.3, 0.1, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LeftbottomX, cs[1].leftbottomY, cs[1].RightbottomX, cs[1].RightbottomY, 0.3, -0.3, 0.1, 0);
		}
		else
		{
			CohenSutherlandLineClipAndDraw(cs[1].LefttopX, cs[1].LefttopY, cs[1].LeftbottomX, cs[1].leftbottomY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[1].RighttopX, cs[1].RighttopY, cs[1].RightbottomX, cs[1].RightbottomY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LefttopX, cs[1].LefttopY, cs[1].RighttopX, cs[1].RighttopY, 0.3, -0.3, 0.05, 0);
			CohenSutherlandLineClipAndDraw(cs[1].LeftbottomX, cs[1].leftbottomY, cs[1].RightbottomX, cs[1].RightbottomY, 0.3, -0.3, 0.05, 0);
		}
	}

	glColor3f(1, 1, 1);
	glPopMatrix();

	//좌표계
	glFlush();
}

GLvoid reshape(int w, int h)    // 다시 그리기 함수 
{
	Windows.Width = w;
	Windows.Height = h;
	glViewport(0, 0, w, h);
}

GLvoid Timer(int value)
{
	abs1 = bt.x - rt.x;
	if (cs[0].bcollide == true || cs[1].bcollide == true)
	{
		angle+=5;
	}
	if (abs1 < 0)
	{
		abs1 = abs1*(-1);
	}

	if (abs1<0.3&&cs[0].y<-0.5&&cs[0].y>-1.5) //바구니에 들어가면 충돌함.
	{
		cs[0].collide = true;
	}
	else if (abs1 >= 0.3&&abs1 < 0.5&&cs[0].y<-0.5&&cs[0].y>-1.5)
	{
		cs[0].bcollide = true;
	}
	if (abs1<0.3&&cs[1].y<-0.5&&cs[1].y>-1.5) //바구니에 들어가면 충돌함.
	{
		cs[1].collide = true;
	}
	else if (abs1 >= 0.3&&abs1 < 0.4&&cs[1].y<-0.5&&cs[1].y>-1.5)
	{
		cs[1].bcollide = true;
	}

	if (rt.cut == true)
	{
		Windows.cutTime++;
		if (cs[0].collide == false && cs[1].collide == false) {
			if (cs[0].size < cs[1].size)
			{
				cs[0].y -= Windows.cutTime*0.05;
			}
			else
			{
				cs[1].y -= Windows.cutTime*0.05;
			}
		}
	}
	bt.time++;
	rt.time++;
	glutTimerFunc(100, Timer, 1);
	glutPostRedisplay();
}

GLvoid KeyBoardInput(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'q':
		exit(0);
		break;
	case 'p':
		bt.time = 0;
		rt.cut = false;
		Windows.cutTime = 0;
		cs[0].x = 0;
		cs[0].y = 0;
		cs[0].collide = false;
		cs[0].LeftbottomX = 0;
		cs[0].leftbottomY = 0;
		cs[0].RightbottomX = 0;
		cs[0].RightbottomY = 0;
		cs[0].LefttopX = 0;
		cs[0].LefttopY = 0;
		cs[0].RighttopX = 0;
		cs[0].RighttopY = 0;
		cs[0].size = 0;
		cs[0].bcollide = false;

		cs[1].x = 0;
		cs[1].collide = false;
		cs[1].y = 0;
		cs[1].LeftbottomX = 0;
		cs[1].leftbottomY = 0;
		cs[1].RightbottomX = 0;
		cs[1].RightbottomY = 0;
		cs[1].LefttopX = 0;
		cs[1].LefttopY = 0;
		cs[1].RighttopX = 0;
		cs[1].RighttopY = 0;
		cs[1].size = 0;
		cs[1].bcollide = false;
		angle = 0;
		rt.time = 0;
		rt.size = rand() % 10 * 0.01 + 0.1;
		break;
	}
	glutPostRedisplay();
}

void Mouse(int button, int state, int x, int y)
{
	int Y = Windows.Height - y;

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		Windows.lineX1 = (double)(x - Windows.Width / 2) / (Windows.Width / 2);
		Windows.lineY1 = (double)(Y - Windows.Height / 2) / (Windows.Height / 2);
		Windows.click = true;
	}
	else if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		Windows.click = false;
	}
	glutPostRedisplay();

}

void Motion(int x, int y) {
	int Y = Windows.Height - y;
	if (Windows.click == true)
	{
		Windows.lineX2 = (double)(x - Windows.Width / 2) / (Windows.Width / 2);
		Windows.lineY2 = (double)(Y - Windows.Height / 2) / (Windows.Height / 2);
	}
	else
	{
		Windows.lineX1 = (double)(x - Windows.Width / 2) / (Windows.Width / 2);
		Windows.lineY1 = (double)(Y - Windows.Height / 2) / (Windows.Height / 2);
	}
	if (Windows.lineY1<rt.y + rt.size&&Windows.lineY1>rt.y - rt.size&&
		Windows.lineY2<rt.y + rt.size&&Windows.lineY2>rt.y - rt.size) //사각형의 가로로 자를 경우
	{
		if (Windows.lineX1<rt.x - rt.size&&
			Windows.lineX2>rt.x + rt.size ||
			Windows.lineX2<rt.x - rt.size&&
			Windows.lineX1>rt.x + rt.size)
		{
			rt.cut = true;
			rt.garo = true;
			Windows.clx1 = rt.x - rt.size;
			Windows.clx2 = rt.x + rt.size;
			Windows.cly1 = (Windows.lineY2 - Windows.lineY1) / (Windows.lineX2 - Windows.lineX1)*//직선의 기울기
				(Windows.clx1 - Windows.lineX1) + Windows.lineY1;
			Windows.cly2 = (Windows.lineY2 - Windows.lineY1) / (Windows.lineX2 - Windows.lineX1)*//직선의 기울기
				(Windows.clx2 - Windows.lineX1) + Windows.lineY1;

			cs[0].y = rt.y;
			cs[0].x = rt.x;
			cs[0].LeftbottomX = -rt.size;
			cs[0].leftbottomY = 0;
			cs[0].RightbottomX = rt.size;
			cs[0].RightbottomY = 0;
			cs[0].LefttopX = -rt.size;
			cs[0].LefttopY = Windows.cly1 - rt.y + rt.size;
			cs[0].RighttopX = rt.size;
			cs[0].RighttopY = Windows.cly2 - rt.y + rt.size;
			cs[0].size = sqrt((cs[0].LeftbottomX - cs[0].RightbottomX)*(cs[0].LeftbottomX - cs[0].RightbottomX) +
				(cs[0].leftbottomY - cs[0].RightbottomY)*(cs[0].leftbottomY - cs[0].RightbottomY))
				+ sqrt((cs[0].RightbottomX - cs[0].RighttopX)*(cs[0].RightbottomX - cs[0].RighttopX) +
				(cs[0].RightbottomY - cs[0].RighttopY)*(cs[0].RightbottomY - cs[0].RighttopY)) +
				sqrt((cs[0].LefttopX - cs[0].RighttopX)*(cs[0].LefttopX - cs[0].RighttopX) +
				(cs[0].LefttopY - cs[0].RighttopY)*(cs[0].LefttopY - cs[0].RighttopY))
				+ sqrt((cs[0].LefttopX - cs[0].LeftbottomX)*(cs[0].LefttopX - cs[0].LeftbottomX) +
				(cs[0].LefttopY - cs[0].leftbottomY)*(cs[0].LefttopY - cs[0].leftbottomY));
			//밑에있는녀석
			cs[1].x = rt.x;
			cs[1].y = rt.y;
			cs[1].LeftbottomX = -rt.size;
			cs[1].leftbottomY = Windows.cly1 - rt.y + rt.size;
			cs[1].RightbottomX = rt.size;
			cs[1].RightbottomY = Windows.cly2 - rt.y + rt.size;
			cs[1].LefttopX = -rt.size;
			cs[1].LefttopY = 2 * rt.size;
			cs[1].RighttopX = rt.size;
			cs[1].RighttopY = 2 * rt.size;
			cs[1].size = sqrt((cs[1].LeftbottomX - cs[1].RightbottomX)*(cs[1].LeftbottomX - cs[1].RightbottomX) +
				(cs[1].leftbottomY - cs[1].RightbottomY)*(cs[1].leftbottomY - cs[1].RightbottomY))
				+ sqrt((cs[1].RightbottomX - cs[1].RighttopX)*(cs[1].RightbottomX - cs[1].RighttopX) +
				(cs[0].RightbottomY - cs[1].RighttopY)*(cs[1].RightbottomY - cs[1].RighttopY)) +
				sqrt((cs[1].LefttopX - cs[1].RighttopX)*(cs[1].LefttopX - cs[1].RighttopX) +
				(cs[1].LefttopY - cs[1].RighttopY)*(cs[1].LefttopY - cs[1].RighttopY))
				+ sqrt((cs[1].LefttopX - cs[0].LeftbottomX)*(cs[0].LefttopX - cs[1].LeftbottomX) +
				(cs[1].LefttopY - cs[1].leftbottomY)*(cs[1].LefttopY - cs[1].leftbottomY));
			//위에있는녀석
			if (cs[0].LefttopY < cs[0].RighttopY)
			{
				ph = cs[0].LefttopY;
			}
			else
			{
				ph = cs[0].RighttopY;
			}
		}
	}
	else if (Windows.lineX1<rt.x + rt.size&&Windows.lineX1>rt.x - rt.size&&
		Windows.lineX2<rt.x + rt.size&&Windows.lineX2>rt.x - rt.size) //사각형의 세로로 자를 경우
	{

		if (Windows.lineY1<rt.y - rt.size&&
			Windows.lineY2>rt.y + rt.size ||
			Windows.lineY2<rt.y - rt.size&&
			Windows.lineY1>rt.y + rt.size)
		{
			cs[0].x = rt.x;
			cs[0].y = rt.y;
			rt.cut = true;
			rt.garo = false;
			Windows.cly1 = rt.y - rt.size;
			Windows.cly2 = rt.y + rt.size;
			Windows.clx1 = (Windows.lineX2 - Windows.lineX1) / (Windows.lineY2 - Windows.lineY1)*
				(Windows.cly1 - Windows.lineY1) + Windows.lineX1;
			Windows.clx2 = (Windows.lineX2 - Windows.lineX1) / (Windows.lineY2 - Windows.lineY1)*
				(Windows.cly2 - Windows.lineY1) + Windows.lineX1;

			cs[0].LeftbottomX = -rt.size;
			cs[0].leftbottomY = 0;
			cs[0].RightbottomX = -rt.size;
			cs[0].RightbottomY = rt.size * 2;
			cs[0].LefttopX = Windows.clx1 - rt.x;
			cs[0].LefttopY = 0;
			cs[0].RighttopX = Windows.clx2 - rt.x;
			cs[0].RighttopY = rt.size * 2;
			cs[0].size = sqrt((cs[0].LeftbottomX - cs[0].RightbottomX)*(cs[0].LeftbottomX - cs[0].RightbottomX) +
				(cs[0].leftbottomY - cs[0].RightbottomY)*(cs[0].leftbottomY - cs[0].RightbottomY))
				+ sqrt((cs[0].RightbottomX - cs[0].RighttopX)*(cs[0].RightbottomX - cs[0].RighttopX) +
				(cs[0].RightbottomY - cs[0].RighttopY)*(cs[0].RightbottomY - cs[0].RighttopY)) +
				sqrt((cs[0].LefttopX - cs[0].RighttopX)*(cs[0].LefttopX - cs[0].RighttopX) +
				(cs[0].LefttopY - cs[0].RighttopY)*(cs[0].LefttopY - cs[0].RighttopY))
				+ sqrt((cs[0].LefttopX - cs[0].LeftbottomX)*(cs[0].LefttopX - cs[0].LeftbottomX) +
				(cs[0].LefttopY - cs[0].leftbottomY)*(cs[0].LefttopY - cs[0].leftbottomY));

			//밑에있는녀석
			cs[1].x = rt.x;
			cs[1].y = rt.y - ph;
			cs[1].LeftbottomX = Windows.clx1 - rt.x;
			cs[1].leftbottomY = 0;
			cs[1].RightbottomX = Windows.clx2 - rt.x;
			cs[1].RightbottomY = rt.size * 2;
			cs[1].LefttopX = rt.size;
			cs[1].LefttopY = 0;
			cs[1].RighttopX = rt.size;
			cs[1].RighttopY = rt.size * 2;
			cs[1].size = sqrt((cs[1].LeftbottomX - cs[1].RightbottomX)*(cs[1].LeftbottomX - cs[1].RightbottomX) +
				(cs[1].leftbottomY - cs[1].RightbottomY)*(cs[1].leftbottomY - cs[1].RightbottomY))
				+ sqrt((cs[1].RightbottomX - cs[1].RighttopX)*(cs[1].RightbottomX - cs[1].RighttopX) +
				(cs[0].RightbottomY - cs[1].RighttopY)*(cs[1].RightbottomY - cs[1].RighttopY)) +
				sqrt((cs[1].LefttopX - cs[1].RighttopX)*(cs[1].LefttopX - cs[1].RighttopX) +
				(cs[1].LefttopY - cs[1].RighttopY)*(cs[1].LefttopY - cs[1].RighttopY))
				+ sqrt((cs[1].LefttopX - cs[0].LeftbottomX)*(cs[0].LefttopX - cs[1].LeftbottomX) +
				(cs[1].LefttopY - cs[1].leftbottomY)*(cs[1].LefttopY - cs[1].leftbottomY));
			//위에있는녀석
		}
	}


	glutPostRedisplay();
}

int ComputeOutCode(double x, double y, double xmax, double xmin, double ymax, double ymin)
{
	int code;

	code = INSIDE;

	if (x < xmin)
		code |= LEFT;
	else if (x > xmax)
		code |= RIGHT;
	if (y < ymin)
		code |= BOTTOM;
	else if (y > ymax)
		code |= TOP;

	return code;
}

// Cohen-Sutherland 클리핑 알고리즘으로 라인을 클립한다.
// P0 = (x0, y0)에서 P1 = (x1, y1)까지의 사각형에 대해
// (xmin, ymin)에서 (xmax, ymax)까지의 대각선.
void CohenSutherlandLineClipAndDraw(double x0, double y0, double x1, double y1, double xmax, double xmin, double ymax, double ymin)
{

	int outcode0 = ComputeOutCode(x0, y0, xmax, xmin, ymax, ymin);
	int outcode1 = ComputeOutCode(x1, y1, xmax, xmin, ymax, ymin);
	bool accept = false;

	while (true) {
		if (!(outcode0 | outcode1)) {
			accept = true;
			break;
		}
		else if (outcode0 & outcode1) {
			break;
		}
		else {


			double x, y;


			int outcodeOut = outcode0 ? outcode0 : outcode1;


			if (outcodeOut & TOP) {
				x = x0 + (x1 - x0) * (ymax - y0) / (y1 - y0);
				y = ymax;
			}
			else if (outcodeOut & BOTTOM) {
				x = x0 + (x1 - x0) * (ymin - y0) / (y1 - y0);
				y = ymin;
			}
			else if (outcodeOut & RIGHT) {
				y = y0 + (y1 - y0) * (xmax - x0) / (x1 - x0);
				x = xmax;
			}
			else if (outcodeOut & LEFT) {
				y = y0 + (y1 - y0) * (xmin - x0) / (x1 - x0);
				x = xmin;
			}

			if (outcodeOut == outcode0) {
				x0 = x;
				y0 = y;
				outcode0 = ComputeOutCode(x0, y0, xmax, xmin, ymax, ymin);
			}
			else {
				x1 = x;
				y1 = y;
				outcode1 = ComputeOutCode(x1, y1, xmax, xmin, ymax, ymin);
			}
		}
	}
	if (accept) {
		glBegin(GL_LINES);
		glColor3f(1, 0, 0);
		glVertex2f(x0, y0);
		glVertex2f(x1, y1);
		glEnd();
	}
}